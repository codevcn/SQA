require('dotenv').config();
const { Builder, By, Key, until } = require('selenium-webdriver');
const { expect } = require('chai');
require('chromedriver');
const axios = require('axios');
const chrome = require('selenium-webdriver/chrome');

const DOMAIN = process.env.DOMAIN;
console.log(`Testing on: ${DOMAIN}`);

const { convertDateFormat, addMinutesToDate, getRelativeTimeFormatted, getTomorrowDateFormatted, getMessageFromToast, clickButton, clickOkToast, getRelativeDateFormatted } = require("./utils/helper")
const { login, logout, placeOrder } = require("./utils/func")

describe('Các testcase cho chức năng đặt đơn đặt chỗ', function () {
    this.timeout(15000)
    let driver;

    before(async function () {
        let options = new chrome.Options();
        // options.addArguments('--headless', '--disable-gpu', '--no-sandbox', '--disable-dev-shm-usage');

        options.addArguments('--disable-gpu', '--no-sandbox', '--disable-dev-shm-usage');
        driver = await new Builder().forBrowser('chrome').setChromeOptions(options).build();
        await driver.manage().setTimeouts({ implicit: 5000 });

    });

    after(async function () {
        if (driver) {
            await driver.quit();
        }
    });
    beforeEach(async function () {
        await axios.get('http://localhost:3000/reset-database');
        await driver.get(`${DOMAIN}/`);
    });


    async function getErrorMessage(inputId) {
        let element = await driver.findElement(By.css(`#${inputId} ~ .message span`));
        return await element.getText();
    }

    it('Không nhập Họ Và Tên', async function () {
        await placeOrder(driver, { phone: '0987654321', date: getTomorrowDateFormatted(), time: '18:00', adults: '2' });
        let message = await getErrorMessage("full-name-input");
        expect(message).to.equal('Trường họ và tên không được để trống!');
    });

    it('Nhập Họ và Tên chứa kí tự đặc biệt', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A!', phone: '0987654321', date: getTomorrowDateFormatted(), time: '18:00', adults: '2' });
        let message = await getErrorMessage("full-name-input");
        expect(message).to.equal('Trường họ và tên không hợp lệ!');
    });
    it('Nhập Họ và Tên chứa kí tự số', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A6', phone: '0987654321', date: getTomorrowDateFormatted(), time: '18:00', adults: '2' });
        let message = await getErrorMessage("full-name-input");
        expect(message).to.equal('Trường họ và tên không hợp lệ!');
    });
    it('Không nhập Số điện thoại', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '', date: getTomorrowDateFormatted(), time: '18:00', adults: '2' });
        let message = await getErrorMessage("phone-input");
        expect(message).to.equal('Số điện thoại không được để trống!');
    });
    it('Số điện thoại không hợp lệ', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '12345A', date: getTomorrowDateFormatted(), time: '18:00', adults: '2' });
        let message = await getErrorMessage("phone-input");
        expect(message).to.equal('Số điện thoại không hợp lệ!');
    });

    it('Không nhập Ngày đặt', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '0987654321', time: '18:00', adults: '2' });
        let message = await getErrorMessage("date-input");
        expect(message).to.equal('Trường ngày đặt không được để trống!');
    });

    it('Không nhập giờ', async function () {
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '0987654321', date: getTomorrowDateFormatted(), adults: '2' });
        let message = await getErrorMessage("time-inp");
        expect(message).to.equal('Trường giờ đặt không được để trống!');
    });

    it('Nhập số người lớn là số âm', async function () {
        this.timeout(10000)
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '0987654321', date: '01-04-2025', time: '18:00', adults: '-1' });
        let message = await getErrorMessage("adults-count-input");
        expect(message).to.equal('Phải có ít nhất 1 người lớn!');
    });

    it('Nhập số người lớn là số 0', async function () {
        this.timeout(10000)
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '0987654321', date: '01-04-2025', time: '18:00', adults: '0' });
        let message = await getErrorMessage("adults-count-input");
        expect(message).to.equal('Phải có ít nhất 1 người lớn!');
    });

    it('Nhập số trẻ em là số âm', async function () {
        this.timeout(10000)
        await placeOrder(driver, { fullName: 'Nguyễn Văn A', phone: '0987654321', date: '01-04-2025', time: '18:00', adults: '1', children: '-1' });
        let message = await getErrorMessage("children-count-input");
        expect(message).to.equal('Số trẻ em phải lớn hơn hoặc bằng 0!');
    });

    it('Nhập các trường đúng yêu cầu', async function () {
        this.timeout(10000)
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: getTomorrowDateFormatted(), time: '19:00', adults: '2', children: '1', note: 'Bàn gần cửa sổ' });

        await clickButton(driver, "//*[@id='confirm-booking-details']/button/span")

        let message = await getMessageFromToast(driver)
        expect(message).to.equal('Đặt bàn thành công');

    });

    it('Tạo 2 đơn liên tiếp cùng 1 đầu vào', async function () {
        this.timeout(10000)
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: getTomorrowDateFormatted(), time: '19:00', adults: '2', children: '1', note: 'Bàn gần cửa sổ' });

        await clickButton(driver, "//*[@id='confirm-booking-details']/button/span")

        await driver.get(`${DOMAIN}`)
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: getTomorrowDateFormatted(), time: '19:00', adults: '2', children: '1', note: 'Bàn gần cửa sổ' });

        await clickButton(driver, "//*[@id='confirm-booking-details']/button/span")

        let message = await getMessageFromToast(driver)
        expect(message).to.equal('Bạn chỉ có thể đặt chỗ cách nhau ít nhất 1 giờ.');

    });

    it('Tạo đơn với thời gian là trong quá khứ', async function () {
        this.timeout(10000)
        const firstTime = getRelativeTimeFormatted(-1)
        const [date, time] = firstTime.split(' ')

        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date, time: time, adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        let message = await getMessageFromToast(driver)
        expect(message).to.equal('Thời gian đặt phải từ thời điểm hiện tại trở đi!');
    });

    it('Tạo đơn với thời gian cách thời gian hiện tại 2 tháng', async function () {
        this.timeout(10000)
        const nextDate = getRelativeDateFormatted(65) //61 ngày
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: nextDate, time: "11:00", adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        let message = await getMessageFromToast(driver)
        expect(message).to.equal('Thời gian đặt không được quá 2 tháng kể từ thời điểm hiện tại!');
    });

    it('Tạo đơn cùng họ và tên, số điện thoại đặt vào thời gian nhỏ hơn 1 giờ', async function () {
        this.timeout(10000)
        const firstTime = getRelativeTimeFormatted(1) // lấy thời gian của 1 tiếng tới 
        const [date1, time1] = firstTime.split(" ")
        const sencondTime = addMinutesToDate(firstTime, 59) //59 phút kể từ firstTime
        const [date2, time2] = sencondTime.split(" ")

        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date1, time: time1, adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        await clickButton(driver, '//*[@id="confirm-booking-details"]/button')

        await driver.get(DOMAIN)
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date2, time: time2, adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        await clickButton(driver, '//*[@id="confirm-booking-details"]/button')

        let message = await getMessageFromToast(driver)

        expect(message).to.equal('Bạn chỉ có thể đặt chỗ cách nhau ít nhất 1 giờ.');
    });
    it('Tạo đơn cùng họ và tên, số điện thoại đặt vào thời gian lớn hơn 1 giờ', async function () {
        this.timeout(10000)
        const firstTime = getRelativeTimeFormatted(1) // lấy thời gian của 1 tiếng tới 
        const [date1, time1] = firstTime.split(" ")
        const sencondTime = addMinutesToDate(firstTime, 61) //61 phút kể từ firstTime
        const [date2, time2] = sencondTime.split(" ")

        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date1, time: time1, adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        await clickButton(driver, '//*[@id="confirm-booking-details"]/button')

        await driver.get(DOMAIN)
        await placeOrder(driver, { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date2, time: time2, adults: '2', children: '1', note: 'Bàn gần cửa sổ' });
        await clickButton(driver, '//*[@id="confirm-booking-details"]/button')

        let message = await getMessageFromToast(driver)

        expect(message).to.equal('Đặt bàn thành công');
    });

    it("Tra cứu đơn", async function () {
        this.timeout(10000)
        const firstTime = getRelativeTimeFormatted(1)
        const [date1, time1] = firstTime.split(" ")
        const dataR = { fullName: 'Nguyễn Anh Tuấn', phone: '0987794267', date: date1, time: time1, adults: '2', children: '1', note: 'Bàn gần cửa sổ' }

        await driver.get(`${DOMAIN}/bookings-history/?Cus_Phone=${dataR.phone}&Cus_FullName=${dataR.fullName}`)


        let cardElements
        try {
            cardElements = await driver.wait(until.elementsLocated(By.className('card-info')), 2000);
        } catch (e) {
            cardElements = []
        }
        let isHas = false;
        for (let i = 0; i < cardElements.length; i++) {
            let contentText = await cardElements[i].getText();
            // Kiểm tra tất cả điều kiện bằng .every()
            const isMatch = [
                dataR.time,
                dataR.fullName,
                dataR.phone,
                convertDateFormat(dataR.date),
                dataR.children,
                dataR.adults,
                dataR.note
            ].every(value => contentText.includes(String(value)));

            if (isMatch) {
                isHas = true;
                break; // Dừng vòng lặp ngay khi tìm thấy phần tử phù hợp
            }
        }
        expect(isHas).to.be.false;
        // expect(cardElements).to.be.an('array').that.is.empty;


        await driver.get(DOMAIN)
        await placeOrder(driver, dataR);
        await clickButton(driver, '//*[@id="confirm-booking-details"]/button')


        await driver.get(`${DOMAIN}/bookings-history/?Cus_Phone=${dataR.phone}&Cus_FullName=${dataR.fullName}`)


        cardElements = await driver.findElements(By.className('card-info'));
        isHas = false;
        for (let i = 0; i < cardElements.length; i++) {
            let contentText = await cardElements[i].getText();
            // Kiểm tra tất cả điều kiện bằng .every()
            const isMatch = [
                dataR.time,
                dataR.fullName,
                dataR.phone,
                convertDateFormat(dataR.date),
                dataR.children,
                dataR.adults,
                dataR.note
            ].every(value => contentText.includes(String(value)));

            if (isMatch) {
                isHas = true;
                break; // Dừng vòng lặp ngay khi tìm thấy phần tử phù hợp
            }
        }
        expect(isHas).to.be.true;

    })



});