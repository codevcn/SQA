import { DataTypes } from 'sequelize';
import sequelize from '../config/db.js';

const Reservation = sequelize.define('Reservation', {
  ReservationID: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  Cus_FullName: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  Cus_Phone: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  ArrivalTime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  NumAdults: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  NumChildren: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  Note: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  Status: {
    type: DataTypes.ENUM('Pending', 'Approved','Rejected'),
    defaultValue: 'Pending',
    allowNull: false
  },
  reject_reason: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'Reservations',
  timestamps: true,
  createdAt: 'CreatedAt',
  updatedAt: 'UpdatedAt',
});

export default Reservation;
