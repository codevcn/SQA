
# BE_BookRestaurant

## Cách chạy dự án

1. Cài thư viện ```npm i```
2. Cấu hình file ```.env``` theo mẫu ```.env.examples```
3. Chạy dự án ``` npm run dev```
4. Các bảng sẽ tự động đồng bộ lên cơ sở dữ liệu